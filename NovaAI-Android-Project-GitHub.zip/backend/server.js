import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "32kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20 }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("Set OPENAI_API_KEY in the server environment.");
  process.exit(1);
}
const client = new OpenAI({ apiKey });
const model = process.env.OPENAI_MODEL || "gpt-6.2-sol";

app.get("/health", (_req, res) => res.json({ ok: true, app: "NovaAI" }));

app.post("/api/chat", async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
      return res.status(400).json({ error: "messages must contain 1–20 items" });
    }
    const safeMessages = messages.map((m) => {
      if (!["user", "assistant"].includes(m?.role) ||
          typeof m?.content !== "string" || !m.content.trim() ||
          m.content.length > 8000) {
        throw new Error("Invalid message format");
      }
      return { role: m.role, content: m.content };
    });

    const response = await client.responses.create({
      model,
      instructions: "Ты NovaAI — дружелюбный, полезный ИИ-помощник. Отвечай на языке пользователя. Будь ясным и безопасным.",
      input: safeMessages
    });
    res.json({ reply: response.output_text || "Не удалось получить текстовый ответ." });
  } catch (error) {
    console.error("Chat request failed:", error.message);
    res.status(500).json({ error: "Не удалось получить ответ от ИИ. Проверь настройки сервера и API." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`NovaAI backend listening on ${port}`));
