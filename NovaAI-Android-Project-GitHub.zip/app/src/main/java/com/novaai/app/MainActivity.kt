package com.novaai.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val history = mutableListOf<Pair<String, String>>()
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var serverField: EditText
    private lateinit var sendButton: Button
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private val prefs by lazy { getSharedPreferences("novaai", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 16, 31)
        window.navigationBarColor = Color.rgb(12, 16, 31)
        window.decorView.systemUiVisibility = 0
        buildUi()
        addMessage("assistant", "Привет! Я NovaAI. Напиши, чем помочь 🙂")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(12, 16, 31))
        }
        val header = TextView(this).apply {
            text = "✦  NovaAI"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }
        page.addView(header, LinearLayout.LayoutParams(-1, dp(48)))

        serverField = EditText(this).apply {
            setSingleLine(true)
            textSize = 13f
            hint = "Адрес сервера, например https://your-server.example"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.rgb(29, 37, 60))
            setText(prefs.getString("server", "") ?: "")
        }
        page.addView(serverField, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })

        status = TextView(this).apply {
            text = "Укажи адрес своего backend-сервера"
            textSize = 12f
            setTextColor(Color.rgb(165, 180, 210))
            setPadding(0, 0, 0, dp(8))
        }
        page.addView(status)

        scroll = ScrollView(this).apply { isFillViewport = true }
        transcript = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }
        scroll.addView(transcript)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Напиши сообщение..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(Color.rgb(29, 37, 60))
            minHeight = dp(50)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(8) })
        sendButton = Button(this).apply {
            text = "➤"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(95, 87, 235))
            setOnClickListener { sendMessage() }
        }
        bottom.addView(sendButton, LinearLayout.LayoutParams(dp(58), dp(52)))
        page.addView(bottom)
        setContentView(page)
    }

    private fun addMessage(role: String, text: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (role == "user") Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val bubble = TextView(this).apply {
            this.text = (if (role == "user") "Вы\n" else "NovaAI\n") + text
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(if (role == "user") Color.rgb(75, 69, 190) else Color.rgb(31, 42, 66))
            maxWidth = (resources.displayMetrics.widthPixels * 0.82).toInt()
        }
        row.addView(bubble)
        transcript.addView(row)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        val base = serverField.text.toString().trim().trimEnd('/')
        if (message.isEmpty()) return
        if (!base.startsWith("https://")) {
            status.text = "Нужен HTTPS-адрес backend-сервера."
            return
        }
        prefs.edit().putString("server", base).apply()
        input.setText("")
        history.add("user" to message)
        addMessage("user", message)
        status.text = "NovaAI думает..."
        sendButton.isEnabled = false

        executor.execute {
            try {
                val url = URL("$base/api/chat")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val messages = JSONArray()
                history.takeLast(20).forEach { (role, content) ->
                    messages.put(JSONObject().put("role", role).put("content", content))
                }
                val body = JSONObject().put("messages", messages).toString()
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) throw Exception("Сервер ответил $code: $responseText")
                val answer = JSONObject(responseText).optString("reply", "Пустой ответ сервера")
                history.add("assistant" to answer)
                runOnUiThread {
                    addMessage("assistant", answer)
                    status.text = "Готов к следующему вопросу"
                    sendButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Ошибка: ${e.message ?: "не удалось подключиться"}"
                    sendButton.isEnabled = true
                }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
